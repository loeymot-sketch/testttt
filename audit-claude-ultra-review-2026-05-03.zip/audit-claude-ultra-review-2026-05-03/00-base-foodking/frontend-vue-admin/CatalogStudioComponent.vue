<template>
    <LoadingComponent :props="loading" />
    <div class="catalog-studio" data-testid="catalog-studio-page">
        <header class="catalog-studio__header">
            <div>
                <p class="catalog-studio__eyebrow">{{ $t("studio.eyebrow") }}</p>
                <h2>{{ $t("studio.title") }}</h2>
                <p class="catalog-studio__subtitle">{{ $t("studio.subtitle") }}</p>
            </div>
            <div class="catalog-studio__header-actions">
                <button v-if="canCreateCategory" type="button" class="db-btn py-2 bg-primary text-white"
                    data-testid="catalog-studio-add-category"
                    @click="showCategoryQuickForm = !showCategoryQuickForm">
                    <i class="lab lab-add-line"></i>
                    <span>{{ $t("button.add_item_category") }}</span>
                </button>
                <button v-if="canCreateItem" type="button" class="db-btn py-2 bg-green-600 text-white"
                    :disabled="!selectedCategoryId" data-testid="catalog-studio-add-product"
                    @click="showProductQuickForm = !showProductQuickForm">
                    <i class="lab lab-add-line"></i>
                    <span>{{ $t("button.add_item") }}</span>
                </button>
            </div>
        </header>

        <section class="catalog-studio__body">
            <aside class="catalog-studio__sidebar">
                <div class="catalog-studio__sidebar-head">
                    <h3>{{ $t("menu.item_categories") }}</h3>
                    <span class="catalog-studio__counter">{{ categories.length }}</span>
                </div>

                <button type="button" class="catalog-studio__category"
                    :class="{ 'catalog-studio__category--active': selectedCategoryId === null }" @click="selectCategory(null)">
                    <strong>{{ $t("studio.all_categories") }}</strong>
                    <small>{{ $t("studio.products_count", { n: totalProducts }) }}</small>
                </button>

                <div v-for="category in categories" :key="category.id" class="catalog-studio__category-row"
                    :data-testid="`catalog-studio-category-row-${category.id}`">
                    <button type="button" class="catalog-studio__category"
                        :class="{ 'catalog-studio__category--active': selectedCategoryId === Number(category.id) }"
                        @click="selectCategory(Number(category.id))">
                        <strong>{{ category.name }}</strong>
                        <small>{{ $t("studio.products_count", { n: category.product_count || productsCountByCategory[category.id] || 0 }) }}</small>
                    </button>
                    <div class="catalog-studio__category-actions" v-if="canEditCategory || canDeleteCategory">
                        <button v-if="canEditCategory" type="button" class="db-table-action view"
                            :title="$t('label.update')" :aria-label="$t('label.update')"
                            :data-testid="`catalog-studio-category-edit-${category.id}`"
                            @click="editCategory(category)">
                            <i class="lab lab-edit-line"></i>
                        </button>
                        <button v-if="canDeleteCategory" type="button" class="db-table-action delete"
                            :title="$t('label.delete')" :aria-label="$t('label.delete')"
                            :data-testid="`catalog-studio-category-delete-${category.id}`"
                            @click="destroyCategory(category)">
                            <i class="lab lab-delete-line"></i>
                        </button>
                    </div>
                </div>

                <router-link class="catalog-studio__settings-link" :to="{ name: 'admin.settings.itemCategory.list' }">
                    <i class="lab lab-setting-line"></i>
                    <span>{{ $t("studio.advanced_settings") }}</span>
                </router-link>

                <form v-if="showCategoryQuickForm" class="catalog-studio__quick-form" @submit.prevent="createCategory">
                    <label class="db-field-title">{{ $t("label.name") }}</label>
                    <input v-model.trim="categoryQuickForm.name" type="text" class="db-field-control" required />
                    <button type="submit" class="db-btn py-2 bg-primary text-white">{{ $t("button.save") }}</button>
                </form>
            </aside>

            <main class="catalog-studio__main">
                <div class="catalog-studio__toolbar">
                    <input v-model.trim="searchTerm" type="text" class="db-field-control" :placeholder="$t('label.search_by_menu_item')" />
                    <router-link class="catalog-studio__stock-link" :to="{ name: 'admin.items.list', query: { focus: 'availability' } }">
                        <i class="lab lab-toggle-on"></i>
                        <span>{{ $t("studio.stock_link") }}</span>
                    </router-link>
                </div>

                <div class="catalog-studio__product-grid" data-testid="catalog-studio-products-grid">
                    <form v-if="showProductQuickForm" class="catalog-studio__quick-form catalog-studio__quick-form--product"
                        @submit.prevent="createProduct">
                        <h4>{{ $t("studio.quick_create_product") }}</h4>
                        <label class="db-field-title">{{ $t("label.name") }}</label>
                        <input v-model.trim="productQuickForm.name" type="text" class="db-field-control" required />
                        <label class="db-field-title">{{ $t("label.price") }}</label>
                        <input v-model.trim="productQuickForm.price" type="text" class="db-field-control" required />
                        <label class="db-field-title">{{ $t("label.description") }}</label>
                        <textarea v-model.trim="productQuickForm.description" class="db-field-control"></textarea>
                        <label class="db-field-title">{{ $t("label.image") }}</label>
                        <input type="file" class="db-field-control" accept="image/png, image/jpeg, image/jpg"
                            data-testid="catalog-studio-product-image-upload" @change="changeQuickProductImage" />
                        <button type="submit" class="db-btn py-2 bg-green-600 text-white">{{ $t("button.save") }}</button>
                    </form>

                    <article v-for="item in filteredProducts" :key="item.id" class="catalog-studio__product">
                        <img class="catalog-studio__product-thumb" :src="item.thumb" :alt="item.name" />
                        <div class="catalog-studio__product-content">
                            <h4>{{ item.name }}</h4>
                            <p>{{ item.category_name }}</p>
                            <div class="catalog-studio__product-meta">
                                <span>{{ item.flat_price }}</span>
                                <span :class="statusClass(item.status)">{{ enums.statusEnumArray[item.status] }}</span>
                            </div>
                            <div class="catalog-studio__stock-inline" data-testid="catalog-studio-stock-inline">
                                <p class="catalog-studio__stock-title">{{ $t("studio.stock_parallel_title") }}</p>
                                <AvailabilityToggleComponent :item-id="Number(item.id)" :branch-id="null"
                                    :is-available="itemIsAvailable(item)"
                                    :unavailable-reason="item.availability_reason || item.unavailable_reason || null"
                                    @availability-changed="onProductAvailabilityChanged" />
                                <small v-if="extractDailyQuota(item)" class="catalog-studio__stock-hint"
                                    :data-testid="`catalog-studio-stock-quota-${item.id}`">
                                    {{ $t("studio.daily_quota_hint", extractDailyQuota(item)) }}
                                </small>
                                <small v-else class="catalog-studio__stock-hint">
                                    {{ $t("studio.stock_parallel_hint") }}
                                </small>
                            </div>
                        </div>
                        <div class="catalog-studio__product-actions">
                            <router-link v-if="canViewItem" :to="{ name: 'admin.item.show', params: { id: item.id } }"
                                class="db-table-action view" :title="$t('label.view')"
                                :data-testid="`catalog-studio-product-view-${item.id}`">
                                <i class="lab lab-view-line"></i>
                            </router-link>
                            <button v-if="canEditItem" type="button" class="db-table-action view"
                                :title="$t('label.configure_wizard')" :aria-label="$t('label.configure_wizard')"
                                :data-testid="`catalog-studio-product-wizard-${item.id}`"
                                @click="openComposerDrawer(item)">
                                <i class="lab lab-cog"></i>
                            </button>
                            <button v-if="canDeleteItem" type="button" class="db-table-action delete"
                                :title="$t('label.delete')" :aria-label="$t('label.delete')"
                                :data-testid="`catalog-studio-product-delete-${item.id}`"
                                @click="destroyItem(item)">
                                <i class="lab lab-delete-line"></i>
                            </button>
                        </div>
                    </article>
                </div>

                <div v-if="filteredProducts.length === 0" class="catalog-studio__empty">
                    <p>{{ $t("message.no_data_available") }}</p>
                </div>
            </main>
        </section>

        <div v-if="composerDrawer.open" class="catalog-studio__composer-overlay" data-testid="catalog-studio-composer-overlay"
            @click.self="closeComposerDrawer">
            <aside class="catalog-studio__composer-drawer">
                <header class="catalog-studio__composer-header">
                    <div>
                        <p class="catalog-studio__composer-eyebrow">{{ $t("studio.composer_drawer_eyebrow") }}</p>
                        <h3>{{ $t("studio.composer_drawer_title", { item: composerDrawer.itemName || '#' }) }}</h3>
                    </div>
                    <div class="catalog-studio__composer-actions">
                        <router-link class="db-btn py-2 bg-primary text-white"
                            :to="{ name: 'admin.items.composer', params: { id: composerDrawer.itemId } }"
                            :data-testid="'catalog-studio-composer-open-full'">
                            <i class="lab lab-export"></i>
                            <span>{{ $t("studio.open_full_page") }}</span>
                        </router-link>
                        <button type="button" class="db-btn py-2" data-testid="catalog-studio-composer-close"
                            @click="closeComposerDrawer">
                            <i class="lab lab-close"></i>
                            <span>{{ $t("button.close") }}</span>
                        </button>
                    </div>
                </header>
                <iframe v-if="composerDrawerUrl" class="catalog-studio__composer-frame" :src="composerDrawerUrl"
                    :title="$t('studio.composer_drawer_title', { item: composerDrawer.itemName || '#' })"
                    data-testid="catalog-studio-composer-frame"></iframe>
            </aside>
        </div>
    </div>
</template>

<script>
import LoadingComponent from "../components/LoadingComponent";
import AvailabilityToggleComponent from "./AvailabilityToggleComponent.vue";
import appService from "../../../services/appService";
import statusEnum from "../../../enums/modules/statusEnum";
import askEnum from "../../../enums/modules/askEnum";
import itemTypeEnum from "../../../enums/modules/itemTypeEnum";
import alertService from "../../../services/alertService";

export default {
    name: "CatalogStudioComponent",
    components: {
        LoadingComponent,
        AvailabilityToggleComponent,
    },
    data() {
        return {
            loading: { isActive: false },
            selectedCategoryId: null,
            searchTerm: "",
            showCategoryQuickForm: false,
            showProductQuickForm: false,
            categoryQuickForm: {
                name: "",
            },
            productQuickForm: {
                name: "",
                price: "",
                description: "",
                image: null,
            },
            composerDrawer: {
                open: false,
                itemId: null,
                itemName: "",
            },
            enums: {
                statusEnum,
                askEnum,
                itemTypeEnum,
                statusEnumArray: {
                    [statusEnum.ACTIVE]: this.$t("label.active"),
                    [statusEnum.INACTIVE]: this.$t("label.inactive"),
                },
            },
            categoriesSearch: {
                paginate: 0,
                order_column: "sort",
                order_type: "asc",
            },
            itemsSearch: {
                paginate: 0,
                order_column: "id",
                order_type: "desc",
            },
            taxesSearch: {
                paginate: 0,
                order_column: "id",
                order_type: "asc",
            },
        };
    },
    computed: {
        canViewItem() {
            return appService.permissionChecker("items_show");
        },
        canEditItem() {
            return appService.permissionChecker("items_edit");
        },
        canCreateItem() {
            return appService.permissionChecker("items_create");
        },
        canDeleteItem() {
            return appService.permissionChecker("items_delete");
        },
        canEditCategory() {
            return appService.permissionChecker("settings");
        },
        canDeleteCategory() {
            return appService.permissionChecker("settings");
        },
        canCreateCategory() {
            return appService.permissionChecker("settings");
        },
        categories() {
            return this.$store.getters["itemCategory/lists"] || [];
        },
        products() {
            return this.$store.getters["item/lists"] || [];
        },
        taxes() {
            return this.$store.getters["tax/lists"] || [];
        },
        defaultTaxId() {
            const firstTax = this.taxes[0];
            return firstTax ? Number(firstTax.id) : null;
        },
        nextItemOrder() {
            // [STUDIO-FIX-P0] ItemRequest.php requires `order` (numeric). Compute next slot
            // by max(order)+1 over loaded items so the new product lands at the end.
            if (!Array.isArray(this.products) || this.products.length === 0) {
                return 1;
            }
            let max = 0;
            for (const it of this.products) {
                const o = Number(it.order || 0);
                if (Number.isFinite(o) && o > max) {
                    max = o;
                }
            }
            return max + 1;
        },
        composerDrawerUrl() {
            if (!this.composerDrawer.itemId || !this.$router?.resolve) {
                return "";
            }
            return this.$router.resolve({
                name: "admin.items.composer",
                params: { id: this.composerDrawer.itemId },
            }).href;
        },
        totalProducts() {
            return this.products.length;
        },
        productsCountByCategory() {
            return this.products.reduce((carry, item) => {
                const key = Number(item.item_category_id || 0);
                carry[key] = (carry[key] || 0) + 1;
                return carry;
            }, {});
        },
        filteredProducts() {
            const q = this.searchTerm.toLowerCase();
            return this.products.filter((item) => {
                if (this.selectedCategoryId !== null && Number(item.item_category_id) !== this.selectedCategoryId) {
                    return false;
                }
                if (!q) {
                    return true;
                }
                return String(item.name || "").toLowerCase().includes(q);
            });
        },
    },
    mounted() {
        this.refreshData();
    },
    methods: {
        statusClass(status) {
            return appService.statusClass(status);
        },
        refreshData() {
            this.loading.isActive = true;
            Promise.all([
                this.$store.dispatch("itemCategory/lists", this.categoriesSearch),
                this.$store.dispatch("item/lists", this.itemsSearch),
                this.$store.dispatch("tax/lists", this.taxesSearch),
            ]).finally(() => {
                this.loading.isActive = false;
            });
        },
        selectCategory(categoryId) {
            this.selectedCategoryId = categoryId;
        },
        openCategoryModal() {
            this.$router.push({ name: "admin.settings.itemCategory.list" });
        },
        openProductCreate() {
            this.$router.push({
                name: "admin.items.list",
                query: { create: "1", item_category_id: this.selectedCategoryId || "" },
            });
        },
        openComposerDrawer(item) {
            this.composerDrawer = {
                open: true,
                itemId: Number(item.id),
                itemName: item.name || "",
            };
        },
        closeComposerDrawer() {
            this.composerDrawer = {
                open: false,
                itemId: null,
                itemName: "",
            };
        },
        onProductAvailabilityChanged() {
            // Keep source-of-truth in backend/store and rehydrate after toggle.
            this.refreshData();
        },
        itemIsAvailable(item) {
            const value = item?.is_available;
            return !(value === false || value === 0 || value === "0");
        },
        extractDailyQuota(item) {
            const total = this.readNumber(item, ["max_daily_qty", "daily_quota", "quota_daily_max"]);
            let remaining = this.readNumber(item, ["daily_qty_remaining", "remaining_daily_qty", "quota_daily_remaining"]);
            if (remaining === null) {
                const sold = this.readNumber(item, ["daily_qty_sold", "sold_daily_qty"]);
                if (total !== null && sold !== null) {
                    remaining = Math.max(total - sold, 0);
                }
            }
            if (total === null || remaining === null) {
                return null;
            }
            return { remaining, total };
        },
        readNumber(source, keys) {
            if (!source || !Array.isArray(keys)) {
                return null;
            }
            for (const key of keys) {
                const candidate = Number(source[key]);
                if (Number.isFinite(candidate)) {
                    return candidate;
                }
            }
            return null;
        },
        changeQuickProductImage(event) {
            const file = event?.target?.files?.[0] || null;
            this.productQuickForm.image = file;
        },
        buildQuickProductPayload() {
            const fd = new FormData();
            fd.append("name", this.productQuickForm.name || "");
            fd.append("price", this.productQuickForm.price || "");
            fd.append("description", this.productQuickForm.description || "");
            fd.append("caution", "");
            fd.append("is_featured", String(askEnum.YES));
            fd.append("is_upsell", String(askEnum.NO));
            fd.append("item_type", String(itemTypeEnum.VEG));
            fd.append("item_category_id", String(this.selectedCategoryId));
            fd.append("tax_id", this.defaultTaxId ? String(this.defaultTaxId) : "");
            fd.append("status", String(statusEnum.ACTIVE));
            fd.append("order", String(this.nextItemOrder));
            if (this.productQuickForm.image) {
                fd.append("image", this.productQuickForm.image);
            }
            return fd;
        },
        editCategory(category) {
            // Édition complète vit dans la page Réglages (champs avancés). On y route en
            // ouvrant la modale d'édition via le state Vuex partagé.
            this.$router.push({
                name: "admin.settings.itemCategory.list",
                query: { edit: String(category.id) },
            });
        },
        destroyCategory(category) {
            if (!this.canDeleteCategory) {
                return;
            }
            appService.destroyConfirmation().then(() => {
                this.loading.isActive = true;
                this.$store.dispatch("itemCategory/destroy", { id: category.id, search: this.categoriesSearch })
                    .then(() => {
                        if (this.selectedCategoryId === Number(category.id)) {
                            this.selectedCategoryId = null;
                        }
                        alertService.successFlip(null, this.$t("menu.item_categories"));
                        this.refreshData();
                    })
                    .catch((err) => {
                        const msg = err?.response?.data?.message || this.$t("error.something_wrong");
                        alertService.error(msg);
                    })
                    .finally(() => {
                        this.loading.isActive = false;
                    });
            }).catch(() => { /* user cancelled */ });
        },
        destroyItem(item) {
            if (!this.canDeleteItem) {
                return;
            }
            appService.destroyConfirmation().then(() => {
                this.loading.isActive = true;
                this.$store.dispatch("item/destroy", { id: item.id, search: this.itemsSearch })
                    .then(() => {
                        alertService.successFlip(null, this.$t("menu.items"));
                        this.refreshData();
                    })
                    .catch((err) => {
                        const msg = err?.response?.data?.message || this.$t("error.something_wrong");
                        alertService.error(msg);
                    })
                    .finally(() => {
                        this.loading.isActive = false;
                    });
            }).catch(() => { /* user cancelled */ });
        },
        createCategory() {
            if (!this.categoryQuickForm.name) {
                return;
            }
            // [STUDIO-FIX-P0] Reset temp state to force POST and avoid PUT to a stale id
            // when an admin has just edited a different category on another page.
            this.$store.dispatch("itemCategory/reset");
            this.loading.isActive = true;
            this.$store.dispatch("itemCategory/save", {
                form: {
                    name: this.categoryQuickForm.name,
                    status: statusEnum.ACTIVE,
                    description: "",
                },
                search: this.categoriesSearch,
            }).then(() => {
                this.categoryQuickForm.name = "";
                this.showCategoryQuickForm = false;
                alertService.successFlip(null, this.$t("menu.item_categories"));
                this.refreshData();
            }).catch((err) => {
                const msg = err?.response?.data?.message || this.$t("error.something_wrong");
                alertService.error(msg);
            }).finally(() => {
                this.loading.isActive = false;
            });
        },
        createProduct() {
            if (!this.selectedCategoryId) {
                alertService.error(this.$t("studio.select_category_first"));
                return;
            }
            // [STUDIO-FIX-P0] Same reset reason as createCategory.
            this.$store.dispatch("item/reset");
            this.loading.isActive = true;
            this.$store.dispatch("item/save", {
                form: this.buildQuickProductPayload(),
                search: this.itemsSearch,
            }).then(() => {
                this.productQuickForm = { name: "", price: "", description: "", image: null };
                this.showProductQuickForm = false;
                alertService.successFlip(null, this.$t("menu.items"));
                this.refreshData();
            }).catch((err) => {
                const errors = err?.response?.data?.errors;
                const firstError = errors ? Object.values(errors).flat()[0] : null;
                const msg = firstError || err?.response?.data?.message || this.$t("error.something_wrong");
                alertService.error(msg);
            }).finally(() => {
                this.loading.isActive = false;
            });
        },
    },
};
</script>

<style scoped>
.catalog-studio {
    display: grid;
    gap: 14px;
}

.catalog-studio__header {
    display: flex;
    justify-content: space-between;
    gap: 16px;
    border: 1px solid #e2e8f0;
    border-left: 4px solid #dc2626;
    background: #fff;
    border-radius: 10px;
    padding: 16px;
}

.catalog-studio__eyebrow {
    margin: 0 0 4px;
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.06em;
    color: #dc2626;
    font-weight: 700;
}

.catalog-studio__header h2 {
    margin: 0;
    font-size: 22px;
    font-weight: 800;
}

.catalog-studio__subtitle {
    margin: 6px 0 0;
    color: #475569;
}

.catalog-studio__header-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    align-items: start;
}

.catalog-studio__body {
    display: grid;
    grid-template-columns: minmax(220px, 280px) 1fr;
    gap: 14px;
    min-height: 520px;
}

.catalog-studio__sidebar,
.catalog-studio__main {
    border: 1px solid #e2e8f0;
    background: #fff;
    border-radius: 10px;
    padding: 12px;
}

.catalog-studio__sidebar {
    display: grid;
    gap: 8px;
    align-content: start;
}

.catalog-studio__sidebar-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.catalog-studio__sidebar-head h3 {
    margin: 0;
    font-size: 16px;
    font-weight: 800;
}

.catalog-studio__counter {
    background: #f1f5f9;
    border-radius: 999px;
    padding: 3px 8px;
    font-size: 12px;
    font-weight: 700;
}

.catalog-studio__category-row {
    display: grid;
    grid-template-columns: 1fr auto;
    gap: 6px;
    align-items: stretch;
}

.catalog-studio__category-actions {
    display: flex;
    gap: 4px;
    align-items: center;
}

.catalog-studio__category {
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    background: #f8fafc;
    text-align: left;
    padding: 10px;
    display: grid;
    gap: 2px;
    width: 100%;
}

.catalog-studio__category strong {
    font-size: 13px;
}

.catalog-studio__category small {
    color: #64748b;
}

.catalog-studio__category--active {
    border-color: #dc2626;
    background: #fff1f2;
}

.catalog-studio__settings-link {
    margin-top: 8px;
    font-size: 13px;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    color: #0f172a;
}

.catalog-studio__quick-form {
    border: 1px dashed #cbd5e1;
    border-radius: 8px;
    padding: 10px;
    display: grid;
    gap: 8px;
}

.catalog-studio__quick-form--product {
    background: #f8fafc;
    border-style: solid;
}

.catalog-studio__quick-form--product h4 {
    margin: 0;
    font-size: 14px;
    font-weight: 800;
}

.catalog-studio__main {
    display: grid;
    gap: 12px;
    align-content: start;
}

.catalog-studio__toolbar {
    display: flex;
    gap: 8px;
}

.catalog-studio__toolbar input {
    flex: 1;
}

.catalog-studio__stock-link {
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    padding: 8px 10px;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    color: #0f172a;
    white-space: nowrap;
}

.catalog-studio__product-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
    gap: 10px;
}

.catalog-studio__product {
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    overflow: hidden;
    background: #fff;
    display: grid;
}

.catalog-studio__product-thumb {
    width: 100%;
    height: 120px;
    object-fit: cover;
    background: #f1f5f9;
}

.catalog-studio__product-content {
    padding: 10px;
    display: grid;
    gap: 4px;
}

.catalog-studio__product-content h4 {
    margin: 0;
    font-size: 14px;
    font-weight: 800;
}

.catalog-studio__product-content p {
    margin: 0;
    color: #64748b;
    font-size: 12px;
}

.catalog-studio__product-meta {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 12px;
}

.catalog-studio__stock-inline {
    margin-top: 6px;
    border-top: 1px dashed #cbd5e1;
    padding-top: 8px;
    display: grid;
    gap: 6px;
}

.catalog-studio__stock-title {
    margin: 0;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    font-weight: 700;
    color: #334155;
}

.catalog-studio__stock-hint {
    color: #64748b;
    font-size: 11px;
}

.catalog-studio__product-actions {
    border-top: 1px solid #e2e8f0;
    padding: 8px;
    display: flex;
    gap: 8px;
}

.catalog-studio__empty {
    border: 1px dashed #cbd5e1;
    border-radius: 10px;
    padding: 28px;
    text-align: center;
    color: #64748b;
}

.catalog-studio__composer-overlay {
    position: fixed;
    inset: 0;
    background: rgba(15, 23, 42, 0.55);
    z-index: 1200;
    display: flex;
    justify-content: flex-end;
}

.catalog-studio__composer-drawer {
    width: min(96vw, 1500px);
    height: 100vh;
    background: #f8fafc;
    border-left: 1px solid #cbd5e1;
    display: grid;
    grid-template-rows: auto 1fr;
}

.catalog-studio__composer-header {
    border-bottom: 1px solid #cbd5e1;
    background: #fff;
    padding: 12px 14px;
    display: flex;
    justify-content: space-between;
    gap: 12px;
}

.catalog-studio__composer-eyebrow {
    margin: 0 0 4px;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    color: #64748b;
    font-weight: 700;
}

.catalog-studio__composer-header h3 {
    margin: 0;
    font-size: 16px;
    font-weight: 800;
}

.catalog-studio__composer-actions {
    display: flex;
    align-items: center;
    gap: 8px;
}

.catalog-studio__composer-frame {
    width: 100%;
    height: 100%;
    border: 0;
    background: #fff;
}

@media (max-width: 1024px) {
    .catalog-studio__body {
        grid-template-columns: 1fr;
    }
}
</style>
